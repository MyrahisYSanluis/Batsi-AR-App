import SwiftUI
import RealityKit
import ARKit

struct ARViewContainer: UIViewRepresentable {
    @Binding var selectedObject: LearnObject?
    @Binding var shouldPlace: Bool
    let categoryColor: Color // Aquí recibimos el color de la categoría

    @MainActor
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        
        // Configuración de rastreo
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal]
        arView.session.run(config)
        
        return arView
    }
    
    @MainActor
    func updateUIView(_ uiView: ARView, context: Context) {
            if shouldPlace, let object = selectedObject {
                
                // 🧹 LA SOLUCIÓN: Borramos todos los objetos (anclas) anteriores
                // para que no se amontonen cuando elijas uno nuevo.
                uiView.scene.anchors.removeAll()
                
                // Usamos el ARLabelManager para crear el modelo con textos
                let uiColor = UIColor(categoryColor)
                let entity = ARLabelManager.createObject(for: object, color: uiColor)
                
                // Colocar el ancla a 0.5 metros frente a la cámara
                let anchor = AnchorEntity(world: [0, 0, -0.5])
                anchor.addChild(entity)
                uiView.scene.addAnchor(anchor)
                
                // Resetear el trigger
                DispatchQueue.main.async {
                    shouldPlace = false
                }
            }
        }
}
