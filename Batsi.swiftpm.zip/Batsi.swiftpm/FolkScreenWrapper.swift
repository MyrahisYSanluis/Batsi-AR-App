import SwiftUI

// Un contenedor de vista reutilizable para todas tus pantallas
struct FolkScreenWrapper<Content: View>: View {
    // El contenido que irá dentro de la pantalla
    let content: Content

    // Inicializador para recibir el contenido
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        ZStack {
            // Capa 1: Fondo de color base (para áreas no cubiertas por la imagen)
            Color(red: 247/255, green: 243/255, blue: 235/255)
                .ignoresSafeArea()

            // Capa 2: Tu imagen de fondo estirada para cubrir todo
            Image("folkImage") // Usa el nombre que pusiste en Assets
                .resizable()
                .scaledToFill() // Estira la imagen para llenar el contenedor
                .ignoresSafeArea() // Hace que cubra hasta los bordes de la pantalla
                .opacity(0.85) // Opcional: baja un poco la opacidad para no distraer

            // Capa 3: El contenido de tu pantalla con márgenes ajustados
            content
                // Ajusta los márgenes aquí. Aumenta estos números para márgenes más grandes.
                // Usaré EdgeInsets para tener más control.
                .padding(EdgeInsets(top: 0, leading: 100, bottom: 0, trailing: 100))
        }
    }
}
